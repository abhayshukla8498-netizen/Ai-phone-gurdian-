package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BatteryInfo
import com.example.data.CleanerViewModel
import com.example.data.DeviceInfo
import com.example.ui.theme.BatteryColor

import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.graphicsLayer

private val GrayText = Color(0xFF94A3B8)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: CleanerViewModel,
    onNavigateToScan: () -> Unit,
    onNavigateToBattery: () -> Unit,
    onNavigateToPremium: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToApkInstaller: () -> Unit,
    modifier: Modifier = Modifier
) {
    val deviceInfo by viewModel.deviceInfo.collectAsState()
    val batteryInfo by viewModel.batteryInfo.collectAsState()
    val isPremium by viewModel.isPremium.collectAsState()
    val isInternetAvailable by viewModel.isInternetAvailable.collectAsState()
    val hasStoragePermission by viewModel.storagePermissionGranted.collectAsState()

    val isBoostingInProgress by viewModel.isBoostingInProgress.collectAsState()
    val boostProgress by viewModel.boostProgress.collectAsState()
    val boostStatusText by viewModel.boostStatusText.collectAsState()

    val context = androidx.compose.ui.platform.LocalContext.current
    var showExplanationDialog by remember { mutableStateOf(false) }

    val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { permissionsMap ->
        val allGranted = permissionsMap.values.all { it }
        viewModel.setStoragePermissionGranted(allGranted)
        viewModel.startScanning()
        onNavigateToScan()
    }

    LaunchedEffect(Unit) {
        viewModel.checkStoragePermissions()
    }

    // Gauge animations
    val transition = rememberInfiniteTransition(label = "gauge_glow")
    val pulseAlpha by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_pulse"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    navigationIcon = {
                        IconButton(
                            onClick = onNavigateToSettings,
                            modifier = Modifier.testTag("settings_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Settings,
                                contentDescription = "Settings",
                                tint = Color.White
                            )
                        }
                    },
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Shield,
                                contentDescription = "Shield Logo",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AI PHONE GUARDIAN",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 2.sp
                                )
                            )
                        }
                    },
                    actions = {
                        // Premium/Ad upgrades removed to satisfy user request
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            },
            containerColor = Color.Transparent,
            modifier = modifier.fillMaxSize()
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                if (deviceInfo == null) {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                } else {
                    val stats = deviceInfo!!
                    val usedStorage = stats.totalStorage - stats.freeStorage
                    val usedPercentage = (usedStorage.toFloat() / stats.totalStorage) * 100
                    val healthScore = (100 - (usedPercentage * 0.8f)).toInt().coerceIn(10, 100)

                    // 1. Large Storage Health circular indicator
                    StorageHealthGauge(
                        usedPercentage = usedPercentage,
                        healthScore = healthScore,
                        pulseAlpha = pulseAlpha,
                        viewModel = viewModel,
                        totalStorage = stats.totalStorage,
                        freeStorage = stats.freeStorage
                    )

                    // 2. Large Scan CTA
                    Button(
                        onClick = {
                            val hasPermission = viewModel.checkStoragePermissions()
                            if (hasPermission) {
                                viewModel.startScanning()
                                onNavigateToScan()
                            } else {
                                showExplanationDialog = true
                            }
                        },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .shadow(8.dp, RoundedCornerShape(16.dp))
                            .testTag("scan_now_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Bolt,
                                contentDescription = "Scan icon",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "SCAN NOW",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp
                                ),
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }

                    // 3. Grid of Diagnostics (Battery, RAM, System, CPUS)
                    DiagnosticsSection(
                        stats = stats,
                        batteryInfo = batteryInfo,
                        onNavigateToBattery = onNavigateToBattery,
                        viewModel = viewModel
                    )

                    // 4. Boost Drive for High Performance
                    DriveBoosterCard(
                        onBoostClick = {
                            viewModel.performDriveBoost {
                                android.widget.Toast.makeText(
                                    context,
                                    "🚀 Drive successfully boosted! Memory reclaimed and speed optimized!",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    )

                    // 5. APK Installer Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(2.dp, RoundedCornerShape(16.dp))
                            .clickable { onNavigateToApkInstaller() }
                            .testTag("home_apk_installer_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.InstallMobile,
                                    contentDescription = "Install APK",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "APK Installer",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Install app packages directly and securely",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                                contentDescription = "Go to APK Installer",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        if (showExplanationDialog) {
            AlertDialog(
                onDismissRequest = { showExplanationDialog = false },
                icon = {
                    Icon(
                        imageVector = Icons.Rounded.Folder,
                        contentDescription = "Storage Permission Icon",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(40.dp)
                    )
                },
                title = {
                    Text(
                        text = "Storage Scan Needed",
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = "AI Phone Guardian scans your device storage to find safe-to-remove system cache, temporary files, duplicates, and large video downloads. No data ever leaves your device.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showExplanationDialog = false
                            val permissions = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                                arrayOf(
                                    android.Manifest.permission.READ_MEDIA_IMAGES,
                                    android.Manifest.permission.READ_MEDIA_VIDEO,
                                    android.Manifest.permission.READ_MEDIA_AUDIO
                                )
                            } else if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                                arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                            } else {
                                arrayOf(
                                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                                )
                            }
                            permissionLauncher.launch(permissions)
                        }
                    ) {
                        Text("Grant Permission")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            showExplanationDialog = false
                            // Scan in fallback/simulated mode
                            viewModel.setStoragePermissionGranted(false)
                            viewModel.startScanning()
                            onNavigateToScan()
                        }
                    ) {
                        Text("Keep Private & Scan Mock Files", color = GrayText)
                    }
                }
            )
        }

        if (isBoostingInProgress) {
            DriveBoostOverlay(
                progress = boostProgress,
                statusText = boostStatusText
            )
        }
    }
}

@Composable
fun StorageHealthGauge(
    usedPercentage: Float,
    healthScore: Int,
    pulseAlpha: Float,
    viewModel: CleanerViewModel,
    totalStorage: Long,
    freeStorage: Long
) {
    val usedSizeStr = viewModel.formatSize(totalStorage - freeStorage)
    val freeSizeStr = viewModel.formatSize(freeStorage)
    val totalSizeStr = viewModel.formatSize(totalStorage)

    val sweepAngle = (usedPercentage / 100f) * 360f
    val animatedSweep = remember { Animatable(0f) }

    LaunchedEffect(sweepAngle) {
        animatedSweep.animateTo(
            targetValue = sweepAngle,
            animationSpec = tween(1200, easing = EaseOutCubic)
        )
    }

    val themePrimary = MaterialTheme.colorScheme.primary
    val themeSecondary = MaterialTheme.colorScheme.secondary

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(210.dp)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                // Background Glow Canvas
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                themePrimary.copy(alpha = pulseAlpha * 0.12f),
                                Color.Transparent
                            )
                        ),
                        radius = size.minDimension / 1.4f
                    )
                }

                // Sector gauge
                Canvas(modifier = Modifier.size(175.dp)) {
                    val strokeWidth = 8.dp.toPx()
                    // Track circle
                    drawCircle(
                        color = Color.White.copy(alpha = 0.05f),
                        style = Stroke(width = strokeWidth)
                    )
                    // Active Arc representation
                    drawArc(
                        color = if (usedPercentage > 85) Color(0xFFF87171) else themePrimary,
                        startAngle = -90f,
                        sweepAngle = animatedSweep.value,
                        useCenter = false,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                }

                // Gauge central score typography
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "$healthScore",
                            style = MaterialTheme.typography.displayLarge.copy(
                                fontWeight = FontWeight.Light,
                                letterSpacing = (-2).sp
                            ),
                            color = Color.White
                        )
                        Text(
                            text = "%",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Normal
                            ),
                            color = themePrimary,
                            modifier = Modifier.padding(bottom = 8.dp, start = 2.dp)
                        )
                    }
                    Text(
                        text = "HEALTH SCORE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 1.5.sp
                        ),
                        color = GrayText
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .background(themePrimary.copy(alpha = 0.12f), CircleShape)
                            .border(1.dp, themePrimary.copy(alpha = 0.25f), CircleShape)
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (healthScore > 80) "OPTIMAL" else if (healthScore > 50) "WARNING" else "DANGER",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                letterSpacing = 1.sp
                            ),
                            color = themePrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Storage Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = "USED STORAGE",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = GrayText
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = usedSizeStr,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "FREE SPACE",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = themePrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = freeSizeStr,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = themePrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Slider Representation
            LinearProgressIndicator(
                progress = { usedPercentage / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(CircleShape),
                color = if (usedPercentage > 85) Color(0xFFFF1744) else themePrimary,
                trackColor = themePrimary.copy(alpha = 0.1f)
            )

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Text(
                    text = "Total Memory: $totalSizeStr",
                    style = MaterialTheme.typography.bodySmall,
                    color = GrayText
                )
            }
        }
    }
}

@Composable
fun PremiumBanner(
    isPremium: Boolean,
    isInternetAvailable: Boolean,
    onNavigateToPremium: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onNavigateToPremium() }
            .shadow(2.dp, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPremium) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
            else MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.3f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isPremium) Icons.Rounded.VerifiedUser else Icons.Rounded.Star,
                contentDescription = "Star badge",
                tint = if (isPremium) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isPremium) "AI Phone Guardian Pro Active" else "Upgrade to Premium Mode",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = if (isPremium) "Enjoy 100% ad-free experience & deep diagnostic logs." else "Remove simulated ads and enable deeper diagnostic reports.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = Icons.Rounded.KeyboardArrowRight,
                contentDescription = "Open premium panel",
                tint = GrayText
            )
        }
    }
}

@Composable
fun DiagnosticsSection(
    stats: DeviceInfo,
    batteryInfo: BatteryInfo,
    onNavigateToBattery: () -> Unit,
    viewModel: CleanerViewModel
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "HARDWARE HEALTH",
            style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            ),
            color = GrayText
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // RAM diagnostics Card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .shadow(1.dp, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Memory,
                            contentDescription = "RAM Icon",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "RAM Status",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = GrayText
                        )
                    }

                    val usedRam = stats.totalRam - stats.freeRam
                    val ramPct = usedRam.toFloat() / stats.totalRam

                    Text(
                        text = "${(ramPct * 100).toInt()}% Used",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    LinearProgressIndicator(
                        progress = { ramPct },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(CircleShape),
                        color = MaterialTheme.colorScheme.primary
                    )

                    Text(
                        text = "Free: ${viewModel.formatSize(stats.freeRam)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = GrayText
                    )
                }
            }

            // Battery diagnostics Card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToBattery() }
                    .shadow(1.dp, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.BatteryChargingFull,
                            contentDescription = "Battery Icon",
                            tint = BatteryColor,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "Battery",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = GrayText
                        )
                    }

                    Text(
                        text = "${batteryInfo.level}% Capacity",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    LinearProgressIndicator(
                        progress = { batteryInfo.level / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(CircleShape),
                        color = BatteryColor
                    )

                    Text(
                        text = "Temp: ${batteryInfo.temperature}°C",
                        style = MaterialTheme.typography.bodySmall,
                        color = GrayText
                    )
                }
            }
        }

        // System Specs card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(1.dp, RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Info,
                        contentDescription = "Info Icon",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "${stats.brand} ${stats.model}",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Android OS ${stats.androidVersion} (API ${stats.sdkVersion}) • ${stats.cpuCores} CPU cores",
                            style = MaterialTheme.typography.bodySmall,
                            color = GrayText
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DriveBoosterCard(
    onBoostClick: () -> Unit
) {
    // Elegant pulsing border / glow animation
    val infiniteTransition = rememberInfiniteTransition(label = "booster_card_glow")
    val glowScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_scale"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(20.dp))
            .clickable { onBoostClick() },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF00F2FE), // Bright Cyan
                            Color(0xFF4FACFE), // Cyber Blue
                            Color(0xFF8B5CF6)  // Hyper Purple
                        )
                    )
                )
                .padding(1.dp) // Glow border effect
        ) {
            Box(
                modifier = Modifier
                    .background(Color(0xFF0A0F1D)) // Rich dark interior
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        // High quality colorful & animated container for the icon
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            Color(0xFFFF007F), // Neon Pink
                                            Color(0xFF7928CA)  // Hot Purple
                                        )
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.RocketLaunch,
                                contentDescription = "Rocket Icon",
                                tint = Color.White,
                                modifier = Modifier
                                    .size(28.dp)
                                    .graphicsLayer(
                                        scaleX = glowScale,
                                        scaleY = glowScale,
                                        rotationZ = -45f
                                    )
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(16.dp))
                        
                        Column {
                            Text(
                                text = "BOOST YOUR DRIVE",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp
                                ),
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "FOR HIGH PERFORMANCE",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                ),
                                color = Color(0xFF00F2FE)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Instantly wipe background clutter & speed up storage pathways 100% on-device.",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF94A3B8),
                                maxLines = 2
                            )
                        }
                    }
                    
                    Icon(
                        imageVector = Icons.Rounded.ChevronRight,
                        contentDescription = "Go Icon",
                        tint = Color(0xFF00F2FE),
                        modifier = Modifier
                            .size(28.dp)
                            .graphicsLayer(scaleX = glowScale, scaleY = glowScale)
                    )
                }
            }
        }
    }
}

@Composable
fun DriveBoostOverlay(
    progress: Float,
    statusText: String,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "overlay_anims")
    
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "gear_rotation"
    )

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    val rocketYOffset by infiniteTransition.animateFloat(
        initialValue = 15f,
        targetValue = -15f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rocket_bounce"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xE6050814)) // Cyber dark slate background
            .clickable(enabled = false) {}, // Intercept clicks
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            Text(
                text = "HYPER DRIVE BOOSTER",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                ),
                color = Color.White
            )
            
            Text(
                text = "ACTIVATING HIGH PERFORMANCE STATE",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                ),
                color = Color(0xFF00F2FE),
                modifier = Modifier.padding(top = 4.dp, bottom = 40.dp)
            )

            // Dynamic Interactive Canvas Gauge & Rotating Speed Turbine
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .padding(10.dp),
                contentAlignment = Alignment.Center
            ) {
                // outer scanning circle
                Canvas(modifier = Modifier.fillMaxSize()) {
                    // Draw neon circular background
                    drawCircle(
                        color = Color(0xFF8B5CF6).copy(alpha = 0.05f),
                        radius = size.minDimension / 2
                    )
                    
                    // Draw outer dashed ring that rotates
                    drawArc(
                        color = Color(0xFF00F2FE).copy(alpha = 0.3f),
                        startAngle = rotation,
                        sweepAngle = 120f,
                        useCenter = false,
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                    )
                    
                    drawArc(
                        color = Color(0xFFFF007F).copy(alpha = 0.3f),
                        startAngle = rotation + 180f,
                        sweepAngle = 120f,
                        useCenter = false,
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // Draw actual booster progress arc
                    drawArc(
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                Color(0xFF00F2FE),
                                Color(0xFF8B5CF6),
                                Color(0xFFFF007F),
                                Color(0xFF00F2FE)
                            )
                        ),
                        startAngle = -90f,
                        sweepAngle = progress * 360f,
                        useCenter = false,
                        style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                // Inner pulsing core with Rocket Launcher icon shooting upwards
                Box(
                    modifier = Modifier
                        .size(150.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFF8B5CF6).copy(alpha = 0.25f * glowAlpha),
                                    Color.Transparent
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.RocketLaunch,
                            contentDescription = "Active Boosting Rocket",
                            tint = Color.White,
                            modifier = Modifier
                                .size(58.dp)
                                .graphicsLayer(
                                    translationY = rocketYOffset,
                                    rotationZ = -45f,
                                    scaleX = 1f + (progress * 0.15f),
                                    scaleY = 1f + (progress * 0.15f)
                                )
                        )
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        // Fire exhaust sparks simulated beautifully
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFF007F).copy(alpha = glowAlpha))
                            )
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFFB300).copy(alpha = glowAlpha * 1.2f))
                            )
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00F2FE).copy(alpha = glowAlpha))
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            // Percentage Text
            Text(
                text = "${(progress * 100).toInt()}%",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                ),
                color = Color.White
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Status message
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF1E293B).copy(alpha = 0.5f))
                    .padding(horizontal = 24.dp, vertical = 12.dp)
            ) {
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = Color(0xFFF1F5F9),
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Linear bar tracking sub-progress
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .width(180.dp)
                    .height(6.dp)
                    .clip(CircleShape),
                color = Color(0xFF00F2FE),
                trackColor = Color(0xFF1E293B)
            )
        }
    }
}
