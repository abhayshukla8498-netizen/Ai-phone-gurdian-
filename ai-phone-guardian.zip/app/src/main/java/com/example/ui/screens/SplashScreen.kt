package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(
    onNavigateNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Current scanning step index (0 to 4)
    var scanStep by remember { mutableStateOf(0) }
    var smoothProgress by remember { mutableStateOf(0f) }
    
    // Logo entrance animations
    val scaleAnim = remember { Animatable(0.2f) }
    val alphaAnim = remember { Animatable(0f) }

    // Infinite transitions for the high-end animations
    val infiniteTransition = rememberInfiniteTransition(label = "cyber_glow")
    
    // Ambient pulsing glow
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Continuous orbital rotation
    val orbitRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbit"
    )

    // Laser scanning sweep line offset (0f to 1f)
    val laserSweepY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = EaseInOutQuad),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser"
    )

    LaunchedEffect(Unit) {
        // Entrance bounce and fade-in
        launch {
            scaleAnim.animateTo(
                targetValue = 1.0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessLow
                )
            )
        }
        launch {
            alphaAnim.animateTo(
                targetValue = 1.0f,
                animationSpec = tween(800)
            )
        }

        // Smooth continuous progress from 0% to 100% over exactly 5000ms (5 seconds)
        launch {
            val startTime = System.currentTimeMillis()
            val duration = 5000L
            while (true) {
                val elapsed = System.currentTimeMillis() - startTime
                val fraction = (elapsed.toFloat() / duration).coerceIn(0f, 1f)
                smoothProgress = fraction
                
                // Update scanStep dynamically based on progress
                scanStep = when {
                    fraction < 0.20f -> 0
                    fraction < 0.45f -> 1
                    fraction < 0.70f -> 2
                    fraction < 0.90f -> 3
                    else -> 4
                }
                
                if (elapsed >= duration) break
                delay(16) // ~60fps smooth updates
            }
            
            // Wait an extra brief moment on completion so they see the completed state, then auto-navigate
            delay(500)
            onNavigateNext()
        }
    }

    val currentScanMessage = when (scanStep) {
        0 -> "INITIALIZING AI GUARDIAN CORE..."
        1 -> "SCANNING SYSTEM STORAGE FOR JUNK..."
        2 -> "OPTIMIZING RAM MEMORY & CACHE..."
        3 -> "VERIFYING SECURITY SIGNATURES..."
        else -> "AI PHONE GUARD SECURED & ACTIVE!"
    }

    val currentProgress = when (scanStep) {
        0 -> 0.15f
        1 -> 0.45f
        2 -> 0.70f
        3 -> 0.90f
        else -> 1.0f
    }

    val themePrimary = MaterialTheme.colorScheme.primary
    val themeSecondary = MaterialTheme.colorScheme.secondary
    val gradientColors = listOf(Color(0xFF00D2FF), Color(0xFF0066FF), Color(0xFF8B5CF6))

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .testTag("splash_screen_root"),
        contentAlignment = Alignment.Center
    ) {
        // 1. Ambient Tech Background Gradients
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Radial central ambient glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        themePrimary.copy(alpha = 0.12f * pulseScale),
                        Color.Transparent
                    ),
                    center = center,
                    radius = size.minDimension / 1.1f
                )
            )
            // Cyber grid subtle corner lights
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(themeSecondary.copy(alpha = 0.05f), Color.Transparent),
                    center = Offset(0f, 0f),
                    radius = size.minDimension / 1.5f
                )
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth()
        ) {
            // 2. Beautiful Cyber Shield Container (Matches User's Requested Shield Design)
            Box(
                modifier = Modifier
                    .scale(scaleAnim.value)
                    .size(280.dp),
                contentAlignment = Alignment.Center
            ) {
                // Orbital Ring 1 (Concentric outer orbit ring)
                Box(
                    modifier = Modifier
                        .size(230.dp)
                        .border(1.5.dp, Brush.sweepGradient(listOf(Color(0xFF00F2FE), Color(0xFF8B5CF6), Color(0xFF00F2FE))), CircleShape)
                        .rotate(orbitRotation)
                        .alpha(0.5f)
                )

                // Orbital Ring 2 (Concentric intermediate glowing orbit ring)
                Box(
                    modifier = Modifier
                        .size(190.dp)
                        .border(1.dp, Color(0xFF00F2FE).copy(alpha = 0.2f), CircleShape)
                        .rotate(-orbitRotation * 0.5f)
                )

                // 6 Orbiting Feature Icons on Concentric Glowing Rings
                val orbitRadius = 115.dp // Radius from center
                val items = listOf(
                    Triple(Icons.Rounded.RocketLaunch, Color(0xFFFF007F), "Rocket Boost"), // Neon Pink/Red
                    Triple(Icons.Rounded.Brush, Color(0xFF10B981), "Junk Cleaner"),       // Neon Green
                    Triple(Icons.Rounded.Delete, Color(0xFFF59E0B), "Trash Scan"),        // Gold/Orange
                    Triple(Icons.Rounded.PieChart, Color(0xFF06B6D4), "RAM Status"),      // Cyan/Blue
                    Triple(Icons.Rounded.FolderOpen, Color(0xFF8B5CF6), "Deep Files"),     // Violet/Purple
                    Triple(Icons.Rounded.Security, Color(0xFF10B981), "Secure Guard")     // Emerald/Green
                )

                items.forEachIndexed { index, item ->
                    val angle = orbitRotation + (index * 60f)
                    val angleRad = Math.toRadians(angle.toDouble())
                    val xOffset = (orbitRadius.value * Math.cos(angleRad)).dp
                    val yOffset = (orbitRadius.value * Math.sin(angleRad)).dp

                    Box(
                        modifier = Modifier
                            .offset(x = xOffset, y = yOffset)
                            .size(38.dp)
                            .shadow(6.dp, CircleShape)
                            .background(Color(0xFF08152D), CircleShape)
                            .border(1.5.dp, item.second, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        // Ambient glow behind icon
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(item.second.copy(alpha = 0.15f), CircleShape)
                        )
                        Icon(
                            imageVector = item.first,
                            contentDescription = item.third,
                            tint = item.second,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Central Shield Container with Smartphone design inside
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .clip(RoundedCornerShape(32.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF091B3A),
                                    Color(0xFF040A15)
                                )
                            )
                        )
                        .border(1.5.dp, Color(0xFF00F2FE).copy(alpha = 0.4f), RoundedCornerShape(32.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    // Inner Phone Screen mock
                    Box(
                        modifier = Modifier
                            .fillMaxSize(0.8f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF020712))
                            .border(1.dp, Color(0xFF0072FF).copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        // Glowing custom circular loading progress around the logo
                        androidx.compose.material3.CircularProgressIndicator(
                            progress = smoothProgress,
                            modifier = Modifier
                                .size(88.dp)
                                .graphicsLayer {
                                    rotationZ = orbitRotation * 1.5f
                                },
                            color = Color(0xFF00F2FE),
                            strokeWidth = 3.5.dp,
                            trackColor = Color(0xFF00F2FE).copy(alpha = 0.12f)
                        )

                        // Glowing animated premium App Icon in center
                        androidx.compose.foundation.Image(
                            painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.ic_launcher_foreground),
                            contentDescription = "App Logo",
                            modifier = Modifier
                                .size(64.dp)
                                .scale(pulseScale)
                                .graphicsLayer {
                                    // Soft high-tech wobble and spin animation matching the pulse
                                    rotationZ = (pulseScale - 1f) * 15f
                                }
                        )

                        // Laser Sweep Line
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .fillMaxHeight(0.04f)
                                .align(Alignment.TopCenter)
                                .graphicsLayer {
                                    translationY = 110.dp.toPx() * laserSweepY
                                }
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            Color(0xFF00F2FE),
                                            Color.Transparent
                                        )
                                    )
                                )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            // 3. Brand Text & Subtitle
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.alpha(alphaAnim.value)
            ) {
                // Gradient Styled "AI Phone Guard" Text
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "AI ",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp
                        ),
                        color = Color(0xFF00D2FF)
                    )
                    Text(
                        text = "Phone Guard",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        ),
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "MILITARY GRADE PROTECTION",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    ),
                    color = Color(0xFF0066FF).copy(alpha = 0.8f),
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(48.dp))

            // 4. Tech Loading Stats & Progress Line
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .alpha(alphaAnim.value)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = currentScanMessage,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.5.sp
                        ),
                        color = Color(0xFF00F2FE),
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "${(smoothProgress * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Custom Premium Tech Progress Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.08f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(smoothProgress)
                            .fillMaxHeight()
                            .clip(CircleShape)
                            .background(
                                Brush.horizontalGradient(gradientColors)
                            )
                    )
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Beautiful interactive entering button that glows when complete
                AnimatedVisibility(
                    visible = scanStep == 4,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut()
                ) {
                    Button(
                        onClick = onNavigateNext,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent
                        ),
                        contentPadding = PaddingValues(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .shadow(8.dp, RoundedCornerShape(26.dp))
                            .background(
                                Brush.horizontalGradient(gradientColors),
                                RoundedCornerShape(26.dp)
                            )
                            .testTag("splash_enter_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "ENTER SECURE DASHBOARD",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                ),
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Rounded.ArrowForward,
                                contentDescription = "Enter",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        // 5. Offline Local Security Notice
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 40.dp)
                .alpha(alphaAnim.value)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.VerifiedUser,
                    contentDescription = "Verified Secure",
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "100% Local • No Data Uploaded",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.4f),
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}
